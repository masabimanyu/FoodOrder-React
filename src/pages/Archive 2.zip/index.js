import SplashScreen from './SplashScreen';
import SignIn from './SignIn';
import Home from './Home';
import FoodDetail from './FoodDetail';
import OrderSummary from './OrderSummary';
import SuccessOrder from './SuccessOrder';

export {
  SplashScreen,
  SignIn,
  Home,
  FoodDetail,
  OrderSummary,
  SuccessOrder,
};
