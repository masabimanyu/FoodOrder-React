import FoodCard from './FoodCard';
import HomeTabSection from './HomeTabSection';
import HomeProfile from './HomeProfile';
import Rating from './Rating';
import Counter from './Counter';
import ItemListFood from './ItemListFood';
import ItemValue from './ItemValue';
import Loading from './Loading';
import Number from './Number';

export {
  FoodCard,
  HomeTabSection,
  HomeProfile,
  Rating,
  Counter,
  ItemListFood,
  ItemValue,
  Loading,
  Number,
};
