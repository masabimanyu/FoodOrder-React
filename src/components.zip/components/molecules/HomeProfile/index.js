import {useNavigation} from '@react-navigation/native';
import React, {useEffect, useState} from 'react';
import {StyleSheet, Text, View, Image, TouchableOpacity} from 'react-native';
import {ProfileDummy} from '../../../assets';
import {getData} from '../../../utils';
import AsyncStorage from '@react-native-async-storage/async-storage';

const HomeProfile = () => {
  
  const navigation = useNavigation();
  const signOut = () => {
    AsyncStorage.multiRemove(['userProfile', 'token']).then(() => {
      navigation.reset({index: 0, routes: [{name: 'SignIn'}]});
    });
  };
  const [photo, setPhoto] = useState(ProfileDummy);

  useEffect(() => {
    navigation.addListener('focus', () => {
      getData('userProfile').then((res) => {
        setPhoto({uri: res.profile_photo_url});
      });
    });
  }, [navigation]);

  return (
    <View style={styles.profileContainer}>
      <View>
        <Text style={styles.appName}>Warteg</Text>
        <Text style={styles.desc}>Kharisma Bahari</Text>
      </View>
      <TouchableOpacity
      onPress={signOut}>
      <Image source={photo} style={styles.profile} />
      </TouchableOpacity>
    </View>
  );
};

export default HomeProfile;

const styles = StyleSheet.create({
  profileContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 30,
    paddingTop: 25,
    paddingBottom: 24,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    backgroundColor: '#fff',
  },
  appName: {fontSize: 22, fontFamily: 'Poppins-Medium', color: '#004d99'},
  desc: {fontSize: 14, fontFamily: 'Poppins-Light', color: '#004d99'},
  profile: {width: 30, height: 30, borderRadius: 8, marginTop: 15,},
});
