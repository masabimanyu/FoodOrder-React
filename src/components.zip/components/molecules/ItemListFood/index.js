import React , {useState, useEffect} from 'react';
import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import Number from '../Number';
import Rating from '../Rating';
import Counter from '../Counter';
import {Gap, Button} from '../../atoms';
import {IcMin, IcPlus} from '../../../assets';

/*
TYPE:
1. product
2. order-summary
3. in-progress
4. past-orders
*/
  
const ItemListFood = ({
  image,
  onPress,
  rating,
  items,
  price,
  type,
  name,
  date,
  desc,
  status,
  picturePath,
  onValueChange,
}) => {
  const onCounterChange = (value) => {
    setTotalItem(value);


  };
  
 const onOrder = () => {
    const totalPrice = totalItem * price;
    const tax = (10 / 100) * totalPrice;
    const total = totalPrice  + tax;
 }

  const TotalHarga = () => {
    const Jumlah = totalItem * price;
    const Pajak = (10 / 100) * Jumlah;
    const TotalBayar = Jumlah + Pajak;
    setTotalHarga(TotalBayar);
  }

  const [totalItem, setTotalItem] = useState(1);
  const [value, setValue] = useState(1);
  const renderContent = () => {
    switch (type) {
      case 'product':
        // item list product seperti di home page
        return (
          <>
            <View style={styles.content}>
              <Image source={picturePath} style={styles.image} />
              <Text style={styles.title}>{name}</Text>
              <Number number={price} style={styles.price} />
            </View>
          </>
        );
      case 'order-summary':
        // item order summary
        return (
          <>
            <View style={styles.content}>
              <Text style={styles.title}>{name}</Text>
              <Number number={price} style={styles.price} />
              {/* <Text style={styles.price}>IDR {price}</Text> */}
            </View>
            <Text style={styles.items}>{items} items</Text>
          </>
        );
      case 'in-progress':
        // item in progress
        return (
          <>
            <View style={styles.content}>
              <Text style={styles.title}>{name}</Text>
              <View style={styles.row}>
                <Text style={styles.price}>{items} items</Text>
                <View style={styles.dot} />
                <Number number={price} style={styles.price} />
              </View>
            </View>
          </>
        );
      case 'past-orders':
        // item past orders
        const formatedDate = new Date(date).toDateString();
        return (
          <>
            <View style={styles.content}>
              <Text style={styles.title}>{name}</Text>
              <View style={styles.row}>
                <Text style={styles.price}>{items} items</Text>
                <View style={styles.dot} />
                <Number number={price} style={styles.price} />
              </View>
            </View>
            <View>
              <Text style={styles.date}>{formatedDate}</Text>
              <Text style={styles.status(status)}>{status}</Text>
            </View>
          </>
        );
      default:
        // item product
        return (
          <>
            <View style={styles.content}>
              <Text style={styles.title}>{name}</Text>
              <Number number={price} style={styles.price} />
            </View>
            <Rating />
          </>
        );
    }
  };

  return (
      <View style={styles.container}>
      <View style={styles.containerList}>
        <Image source={image} style={styles.image} />
        {renderContent()}
        <Counter style={styles.counter} onValueChange={onCounterChange} />
      </View>
      <Gap height={10} />
      </View>
  );
};

export default ItemListFood;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 6,
  },
  containerList: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: 'white',
    paddingVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 1.8,
    shadowRadius: 15,  
    elevation: 10,
    borderRadius: 18,
  },
  counter: {
    marginRight: 15,
  },
  image: {
    width: 55,
    height: 55,
    borderRadius: 15,
    overflow: 'hidden',
    marginLeft: 10,
  },
  content: {flex: 2,
  flexDirection: 'column',
   marginLeft: 20,
  },
  picturePath: {
 marginLeft: 10,
  },
  title: {
    fontFamily: 'Poppins-Regular',
    fontSize: 20,
    color: '#020202',
  },
  price: {
    fontFamily: 'Poppins-Regular',
    fontSize: 15,
    color: '#8D92A3',
  },
  items: {fontSize: 13, fontFamily: 'Poppins-Regular', color: '#8D92A3'},
  date: {fontSize: 10, fontFamily: 'Poppins-Regular', color: '#8D92A3'},
  status: (status) => ({
    fontSize: 10,
    fontFamily: 'Poppins-Regular',
    color: status === 'CANCELLED' ? '#D9435E' : '#1ABC9C',
  }),
  row: {flexDirection: 'row', alignItems: 'center'},
  dot: {
    width: 3,
    height: 3,
    borderRadius: 3,
    backgroundColor: '#8D92A3',
    marginHorizontal: 4,
  },
  footer: {flexDirection: 'row', paddingVertical: 86, alignItems: 'center', backgroundColor:'#FFC700',},
  priceContainer: {flex: 1},
  button: {width: 163},
  labelTotal: {fontSize: 13, fontFamily: 'Poppins-Regular', color: '#8D92A3', marginLeft: 15,},
  priceTotal: {fontSize: 18, fontFamily: 'Poppins-Regular', color: '#020202', marginLeft: 15,},
});